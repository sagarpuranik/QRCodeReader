﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Imaging;
using Spire.Pdf;

namespace PdfToImage
{
    public class Pdf2Image
    {
        private string _filePath;
        public Pdf2Image(string path)
        {
            _filePath = path;
        }

        public void ConvertImage()
        {
            PdfDocument document = new PdfDocument(_filePath);

            for (int i = 0; i < document.Pages.Count; i++)
            {
                Image bmp = document.SaveAsImage(i);

                bmp.Save("converted\\" + i + ".bmp", ImageFormat.Bmp);
            }
        }
    }
}
