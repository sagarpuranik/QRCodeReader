﻿namespace QrCodeReader
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDecode = new System.Windows.Forms.Button();
            this.pbQRCode = new System.Windows.Forms.PictureBox();
            this.txtDecodePath = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lstDecodedLinks = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbQRCode)).BeginInit();
            this.SuspendLayout();
            // 
            // btnDecode
            // 
            this.btnDecode.Location = new System.Drawing.Point(564, 43);
            this.btnDecode.Name = "btnDecode";
            this.btnDecode.Size = new System.Drawing.Size(75, 23);
            this.btnDecode.TabIndex = 0;
            this.btnDecode.Text = "Decode";
            this.btnDecode.UseVisualStyleBackColor = true;
            // 
            // pbQRCode
            // 
            this.pbQRCode.Location = new System.Drawing.Point(12, 13);
            this.pbQRCode.Name = "pbQRCode";
            this.pbQRCode.Size = new System.Drawing.Size(307, 298);
            this.pbQRCode.TabIndex = 1;
            this.pbQRCode.TabStop = false;
            // 
            // txtDecodePath
            // 
            this.txtDecodePath.Location = new System.Drawing.Point(399, 17);
            this.txtDecodePath.Name = "txtDecodePath";
            this.txtDecodePath.Size = new System.Drawing.Size(240, 20);
            this.txtDecodePath.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(364, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Path";
            // 
            // lstDecodedLinks
            // 
            this.lstDecodedLinks.FormattingEnabled = true;
            this.lstDecodedLinks.Location = new System.Drawing.Point(338, 71);
            this.lstDecodedLinks.Name = "lstDecodedLinks";
            this.lstDecodedLinks.Size = new System.Drawing.Size(301, 238);
            this.lstDecodedLinks.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(651, 504);
            this.Controls.Add(this.lstDecodedLinks);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtDecodePath);
            this.Controls.Add(this.pbQRCode);
            this.Controls.Add(this.btnDecode);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pbQRCode)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnDecode;
        private System.Windows.Forms.PictureBox pbQRCode;
        private System.Windows.Forms.TextBox txtDecodePath;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lstDecodedLinks;
    }
}

